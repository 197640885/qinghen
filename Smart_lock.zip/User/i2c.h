/*
 * i2c.h
 *
 *  Created on: Mar 22, 2022
 *      Author: ExplodingONC
 */

#ifndef USER_I2C_H_
#define USER_I2C_H_

#include "debug.h"

void IIC_Init(u32 bound, u16 address);

#endif /* USER_I2C_H_ */
